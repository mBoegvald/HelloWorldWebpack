// Styles
import "./css/styles.css";

// Main app
import App from "./scripts/App";

document.addEventListener("DOMContentLoaded", () => new App());
