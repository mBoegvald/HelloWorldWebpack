import Swiper from "./Swiper";
import ChangeNavColor from "./ChangeNavColor";

export default class App {
  constructor() {
    new Swiper();
    new ChangeNavColor();
  }
}
